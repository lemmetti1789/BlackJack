package blackJackProject;

import java.util.Scanner;

public class BlackJack {

	public static void main(String[] args) {
		
		//Beginning Message Displayed to User
		
		System.out.println("Welcome to the game of Blackjack!");
		
		//making the deck
		
		Deck pDeck = new Deck();
		pDeck.createFullDeck();
		pDeck.shuffle();
		//System.out.println(pDeck); check used to make sure deck created and shuffled properly
		
		//cards for the player
		Deck humanDeck = new Deck();
		Deck houseDeck = new Deck();
		double pMoney = 100.00;  // in case we get into pennies as it is gambling.   
		
		Scanner userInput = new Scanner(System.in);
		
		
		//Loop for Blackjack (player / dealer)
		while(pMoney > 0) {
			System.out.println("Player has $" + pMoney + ", what do you want to bet?");
			double pBet = userInput.nextDouble();
			if(pBet > pMoney) {
				System.out.println("you cannot play without money get out of my casino!");
				break; // skips everything and takes you to the end.
			}
			
			boolean handOver = false;
			
			//dealing for player's two cards
			humanDeck.draw(humanDeck);
			humanDeck.draw(humanDeck);
			// dealing for dealer's two cards
			houseDeck.draw(pDeck);
			houseDeck.draw(pDeck);
			
			while(true) {
				System.out.println("your curent hand is:");
				System.out.println(humanDeck.toString());
				System.out.println("Value of your hand:" + humanDeck.cardsValue());
				
				//dealer;s hand with one hidden
				System.out.println("dealer's card:"+ houseDeck.getCard(0).toString()+ "and the closed card");
				
				//Player's move
				System.out.println("Hit press (1) or stand press (2)");
				int response = userInput.nextInt();
				
				//player hit's
				if(response == 1) {
					humanDeck.draw(pDeck);
					System.out.println("you drew a:" + humanDeck.getCard(humanDeck.deckSize()-1).toString());//card added most recently
					//if player busts meaning over 21
					if(humanDeck.cardsValue() > 21) {
						System.out.println("Bust.  valued at:" + humanDeck.cardsValue());
						handOver = true;
						
					}
				}
				
				if(response == 2) {
					break;
				}
			}
			// show dealer cards
			System.out.println("Dealer Hand:" + houseDeck.toString());
			/// see if dealer has more points than user
			if(houseDeck.cardsValue() > humanDeck.cardsValue()&& handOver == false) {
				System.out.println("Dealer wins");
				pMoney -= pBet;
				handOver = true;
			}
			//dealer only draws above 15.
			while((houseDeck.cardsValue() < 17) && handOver == false) {
				houseDeck.draw(humanDeck);
				System.out.println("dealer drew" + houseDeck.getCard(houseDeck.deckSize()-1).toString()); // what card the dealer just drew (so last card on array list
			}	
				System.out.println("Dealer's hand is total:" + houseDeck.cardsValue());	//dealer's hand total
			if((houseDeck.cardsValue()> 21)&& handOver == false) {
					System.out.println("dealer busted player wins!");
					pMoney += pBet;
					handOver = true;
			}
			// if there is a tie or a bust (Dealer wins)
			if((humanDeck.cardsValue() == houseDeck.cardsValue()) && handOver == false) {
				System.out.println("tie, dealer wins (Casino rules");
				pMoney -= pBet;
				handOver = true;
			}
			if((humanDeck.cardsValue() > houseDeck.cardsValue()) && handOver == false) {
				System.out.println("Player wins!  Congratulations lets bet more next time!");
				pMoney += pBet;
				handOver = true;
			}
			else if(handOver == false) {
				System.out.println("You have lost");
				pMoney -= pBet;
				handOver = true;
			}
			humanDeck.moveAllToDeck(pDeck); // this puts player cards back in the deck.
			houseDeck.moveAllToDeck(pDeck); // this puts dealer cards back in deck
			System.out.println("Iteration over, Next game");
			

		}
		System.out.println("You have lost everything, and are completetly broke!");  //this moves 
		System.out.println("The house always wins, Gambling is not good!");// when player is at no money these messages will display.  Game over.
				
	}

}
