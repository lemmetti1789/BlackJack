package blackJackProject;

public class Card {
 	//  every card needs suit + value and this is made private because this is the lowest in the chain and we want this encapsulated.   
	private Suit suit; //linking to enumerators (constants)
	private Value value;
	//  Simple constructor for suit and Value linking to Enumerator classes
	public Card(Suit suit, Value value) {  //card constructor
		this.value = value;  // instances of the card
		this.suit = suit;    // instances of the suit
	}
	public String toString() {
		return this.suit.toString() +"__" + this.value.toString();    //return statements are used with tostring because now we can return the suit and a gap plus a value for each card.
		//this will always return the suit + value of the card
	}
	// this will be used to check what the total value of the hand is for the player / dealer when cards are added up.
	public Value getValue() {
		return this.value;  // again return used because we are using values to show the total of the player or dealer.
	}
}