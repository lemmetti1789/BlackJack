package blackJackProject;

public enum Suit {
	CLUBS, SPADES, DIAMONDS, HEARTS
}
// constants so I made it an enumerator class
