package blackJackProject;

import java.util.ArrayList;
import java.util.Random;

public class Deck {

	private ArrayList <Card> cards;  // making an array of using Card 
	
	//constructor using this to create the deck out of an array.
	public Deck() {
		this.cards = new ArrayList<Card>();// setting up the deck with a this method
	}
	
	public void createFullDeck() {//void because we are not returning anything.  just creating a method to build our deck
		//Generate Cards
		for(Suit cardSuit : Suit.values()) { // for each loop to be used with ArrayList (googled this).   for each loop is the best to use for ArrayList to pull out a value.
			for(Value cardValue : Value.values()) {
				//add a new card 
				this.cards.add(new Card(cardSuit, cardValue));//method to add  a new card using the above arrays referencing the enumerator classes.
				
			}
		}
	}
	
	public void shuffle() {//void again because it's just a method to shuffle.  no actual return.
		//pull cards out of deck and put into another deck like they do at a Casino so cards cannot be counted or at least not as well
		// temporary deck and our deck
		ArrayList<Card> TemporaryDeck = new ArrayList<Card>(); // creates an array using class card into a temporary deck.
		Random random = new Random();//has to be imported from java.util like scanner//have to use the random generator which google taught me
		int randomCardList = 0;
		int originalSize = this.cards.size();  
		for(int i = 0; i < originalSize; i++) {
			//generating random cards
			randomCardList = random.nextInt((this.cards.size()-1 - 0) +1) +0;
			TemporaryDeck.add(this.cards.get(randomCardList));  //adds card from random list or the new array from temporary deck
			this.cards.remove(randomCardList);  // remove from starting deck
			
		}
		
		this.cards = TemporaryDeck;  //this puts them back into the deck
		
		
	}

	public String toString() {//this returns all of our cards above in a string method.
		String cardListOutput = "";
		for(Card xCard : this.cards){
			cardListOutput += ":\n" + " -" +xCard.toString(); // new line for every card with all of our card values.
		
		}
		return cardListOutput;// this is what prints it out in the console
		
	}
	
	public void removeCard(int i) {//method to remove a card.
		this.cards.remove(i);
	}
	public Card getCard(int i) {//method to get a card
		return this.cards.get(i);
	}
	public void addCard(Card addCard) {// method to add a card.
		this.cards.add(addCard);
	}
	
	//this method will be to draw from the deck (
	public void draw(Deck cFrom) {// draws from the top of the deck which is (0) in this ArrayList.
		this.cards.add(cFrom.getCard(0));   //beginning of array list is like top of deck
		cFrom.removeCard(0);// when this card is drawn it is also removed.
	}
	public int deckSize() {
		return this.cards.size();
	}
	public void moveAllToDeck(Deck moveTo) {// method of moving cards
		int thisDeckSize = this.cards.size();
		
		for(int i = 0; i < thisDeckSize; i++) {
			moveTo.addCard(this.getCard(i));
		}
		for(int i = 0; i < thisDeckSize; i++) {
			this.removeCard(0);
		}
	}
	public int cardsValue() {// this is where the value of the card is assigned.   I used a switch pattern because each card has its own unique value and you are checking to make sure it equals a certain value.
		int sumValue = 0;
		int aces = 0;
		for(Card xCard : this.cards)// this takes us through the array. {
			switch(xCard.getValue()) {
			case TWO: sumValue =+2; break;
			case THREE: sumValue =+3; break;
			case FOUR: sumValue =+4; break;
			case FIVE: sumValue =+5; break;
			case SIX: sumValue =+6; break;
			case SEVEN: sumValue =+7; break;
			case EIGHT: sumValue =+8; break;
			case NINE: sumValue =+9; break;
			case TEN: sumValue =+10; break;
			case JACK: sumValue =+10; break;
			case QUEEN: sumValue =+10; break;
			case KING: sumValue =+10; break;
			case ACE: aces +=1; break;
			}
		
		// this for loop decides whether the ace will be an 11 or a 1 based on what the value of the current hand is at.  (this I had to google).   I had no idea how I could assign a value to the ace seeeing as it has 1 or 11 possibilities.
		// but once I saw the logic in a for loop it makes perfect sense.   
		for(int i =0; i < aces; i++) {
			if(sumValue > 10) {
				sumValue +=1;
			}
			else {sumValue += 11;
			}
		}
		
		return sumValue;
		
	}
}
