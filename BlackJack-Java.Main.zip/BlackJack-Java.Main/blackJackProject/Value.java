package blackJackProject;

//this is pretty self explanatory.   These are the values of the cards and I made it an enumerator class because they once again are constants.   They do not change so I just listed them out.
public enum Value {
	TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE
}// in black jack there is no 1 / and the face cards are 10 each / Ace is 1 or 11/ so those will have to be defined in Deck class.
	



